// All fixtures are generated here; no company workbook or network request is used.
const REGION_NAMES = [
  ['Northeast','东北大区'],['North','华北大区'],['Shandong','山东特区'],
  ['Northwest','西北大区'],['Central North','中北大区'],['Southwest','西南大区'],
  ['East','华东大区'],['Zhejiang','浙江特区'],['South','华南大区'],['Central','华中大区'],
];
const PRODUCT_NAMES = [['CT','CT'],['Dental chairs','牙椅'],['Scanners','口扫'],['Lasers','激光'],['Microscopes','显微']];
const choose = (lang,en,zh) => lang === 'zh' ? zh : en;
const percent = value => `${(value * 100).toFixed(2)}%`;
const column = index => {
  let result = '';
  for (let n = index + 1; n > 0; n = Math.floor((n - 1) / 26)) result = String.fromCharCode(65 + (n - 1) % 26) + result;
  return result;
};
const dated = day => `2025-07-${String(day).padStart(2,'0')}`;
const sum = values => values.reduce((total,value) => total + value,0);

export function createReport(cutoff = '2025-07-21', lang = 'zh') {
  if (!/^2025-07-(0[1-9]|[12]\d|3[01])$/.test(cutoff)) throw new Error('The demonstration covers July 2025.');
  const i = lang === 'zh' ? 1 : 0;
  const regions = REGION_NAMES.map(names => names[i]);
  const products = PRODUCT_NAMES.map(names => names[i]);
  const leads = [], opportunities = [], targets = [];
  regions.forEach((region,r) => {
    products.forEach((product,p) => {
      const target = 12 + (r * 7 + p * 11) % 28;
      targets.push({key:`${region}|${product}`,target,region,product});
      const count = Math.round(target * (0.4 + ((r * 29 + p * 17) % 110) / 100));
      for (let n = 0; n < count; n++) leads.push({date:dated(1 + (n * 7 + r * 3 + p * 5) % 31),region,product,quantity:1});
    });
    for (let n = 0; n < 8 + (r * 5) % 19; n++) opportunities.push({date:dated(1 + (n * 11 + r) % 31),region});
  });
  const inPeriod = record => record.date >= '2025-07-01' && record.date <= cutoff;
  const rows = regions.map(region => ({
    region,
    opportunities:opportunities.filter(record => record.region === region && inPeriod(record)).length,
    products:products.map(product => {
      const actual = sum(leads.filter(record => record.region === region && record.product === product && inPeriod(record)).map(record => record.quantity));
      const target = targets.find(record => record.region === region && record.product === product).target;
      return {actual,target,rate:target ? actual / target : 0,gap:actual-target};
    }),
  }));
  const total = {
    region:choose(lang,'Total','总计'),
    opportunities:sum(rows.map(row => row.opportunities)),
    products:products.map((_,p) => {
      const actual = sum(rows.map(row => row.products[p].actual));
      const target = sum(rows.map(row => row.products[p].target));
      return {actual,target,rate:target ? actual/target : 0,gap:actual-target};
    }),
  };
  return {lang,cutoff,start:'2025-07-01',progress:Number(cutoff.slice(-2))/31,regions,products,rows,total,leads,opportunities,targets};
}

export function describeCell(model, selection) {
  const {lang,cutoff,start,progress,rows,total,products,leads,opportunities,targets} = model;
  const t = (en,zh) => choose(lang,en,zh);
  const names = {leads:t('LeadData','意向明细'),targets:t('Targets','目标表'),opps:t('Opportunities','机会明细')};
  const totalSelected = selection.row === 'total';
  const row = totalSelected ? total : rows[selection.row];
  const rowNumber = totalSelected ? 16 : 6 + selection.row;
  const actualCol = 2 + selection.product * 4;
  const actualAddress = `${column(actualCol)}${rowNumber}`;
  const targetAddress = `${column(actualCol+1)}${rowNumber}`;
  const item = row?.products[selection.product];
  const result = {address:'',value:'',context:'',formula:'',explanation:'',rule:'',headers:[],inputs:[],inputCount:0};
  const quoted = value => value.replaceAll('"','""');
  const filters = t(`Records from ${start} through ${cutoff}.`,`统计范围：${start} 至 ${cutoff}。`);
  if (selection.kind === 'progress') {
    return {...result,address:'N2',value:percent(progress),context:t('Monthly time progress','月度时间进度'),
      formula:'=DAY($D$2)/DAY(EOMONTH($D$2,0))',
      explanation:t(`${Number(cutoff.slice(-2))} elapsed days ÷ 31 days = ${percent(progress)}.`,`${Number(cutoff.slice(-2))} 天 ÷ 当月 31 天 = ${percent(progress)}。`),
      headers:[t('Reference','引用位置'),t('Value','值')],inputs:[['D2',cutoff]],inputCount:1};
  }
  const context = `${row.region} · ${selection.kind === 'opportunity' ? t('Sales opportunities','销售机会') : products[selection.product]}`;
  result.context = context;
  const kindLabels = {actual:t('Actual','实际'),target:t('Target','目标'),rate:t('Attainment','达成率'),gap:t('Gap','差距'),opportunity:t('Sales opportunities','销售机会')};
  result.context += ` · ${kindLabels[selection.kind]}`;
  result.address = selection.kind === 'opportunity' ? `B${rowNumber}` : `${column(actualCol + ['actual','target','rate','gap'].indexOf(selection.kind))}${rowNumber}`;
  const value = selection.kind === 'opportunity' ? row.opportunities : item[selection.kind];
  result.value = selection.kind === 'rate' ? percent(value) : selection.kind === 'gap' && value < 0 ? `(${Math.abs(value)})` : String(value);
  if (totalSelected && ['actual','target','opportunity'].includes(selection.kind)) {
    const letter = selection.kind === 'opportunity' ? 'B' : column(actualCol + (selection.kind === 'target' ? 1 : 0));
    result.formula = `=SUM(${letter}6:${letter}15)`;
    result.explanation = t('Sum the corresponding values across the ten regions.','对十个区域的对应数值求和。');
    result.headers = [t('Cell','单元格'),t('Region','区域'),t('Value','值')];
    result.inputs = rows.map((r,i) => [`${letter}${i+6}`,r.region,selection.kind === 'opportunity' ? r.opportunities : r.products[selection.product][selection.kind]]);
  } else if (selection.kind === 'actual') {
    const end = leads.length+1;
    result.formula = `=SUMIFS(${names.leads}!$D$2:$D$${end},${names.leads}!$B$2:$B$${end},$A${rowNumber},${names.leads}!$C$2:$C$${end},"${quoted(products[selection.product])}",${names.leads}!$A$2:$A$${end},">="&$B$2,${names.leads}!$A$2:$A$${end},"<="&$D$2)`;
    result.explanation = t(`Sum lead quantities for this region and product. ${filters}`,`筛选该区域、该器械的记录，对新增意向数量求和。${filters}`);
    result.headers = [t('Source row','源数据行'),t('Date','日期'),t('Region','区域'),t('Product','器械'),t('Quantity','数量')];
    result.inputs = leads.flatMap((record,i) => record.region === row.region && record.product === products[selection.product] && record.date >= start && record.date <= cutoff ? [[i+2,record.date,record.region,record.product,record.quantity]] : []);
  } else if (selection.kind === 'target') {
    const key = `${row.region}|${products[selection.product]}`;
    result.formula = `=IFERROR(VLOOKUP($A${rowNumber}&"|${quoted(products[selection.product])}",${names.targets}!$A$2:$B$${targets.length+1},2,FALSE),0)`;
    result.explanation = t('Look up the full-month target using the region–product key. FALSE requests an exact match.','用“区域＋器械”组合键精确查找整月目标；FALSE 表示精确匹配。');
    result.headers = [t('Source row','源数据行'),t('Lookup key','查找键'),t('Monthly target','月目标')];
    result.inputs = [[targets.findIndex(record => record.key === key)+2,key,item.target]];
  } else if (selection.kind === 'opportunity') {
    const end = opportunities.length+1;
    result.formula = `=COUNTIFS(${names.opps}!$B$2:$B$${end},$A${rowNumber},${names.opps}!$A$2:$A$${end},">="&$B$2,${names.opps}!$A$2:$A$${end},"<="&$D$2)`;
    result.explanation = t(`Count opportunity records for this region. ${filters}`,`按区域和日期条件统计销售机会条数。${filters}`);
    result.headers = [t('Source row','源数据行'),t('Date','日期'),t('Region','区域')];
    result.inputs = opportunities.flatMap((record,i) => record.region === row.region && record.date >= start && record.date <= cutoff ? [[i+2,record.date,record.region]] : []);
  } else {
    result.headers = [t('Reference','引用位置'),t('Meaning','含义'),t('Value','值')];
    result.inputs = [[actualAddress,t('Actual','实际'),item.actual],[targetAddress,t('Target','目标'),item.target]];
    if (selection.kind === 'rate') {
      result.formula = `=IFERROR(${actualAddress}/${targetAddress},0)`;
      result.explanation = t(`Actual ${item.actual} ÷ target ${item.target} = ${percent(item.rate)}.${totalSelected ? ' The total is recalculated from total actuals and targets, not averaged from regional percentages.' : ''}`,`实际 ${item.actual} ÷ 目标 ${item.target} = ${percent(item.rate)}。${totalSelected ? '总计达成率由实际合计 ÷ 目标合计重新计算，不对各区域百分比取平均。' : ''}`);
      const meets = item.rate >= progress;
      result.rule = `${t('Conditional formatting','条件标色')}：${result.address} ${meets ? '≥' : '<'} $N$2 (${percent(progress)}) → ${meets ? t('green','绿色') : t('red','红色')}。`;
      result.inputs.push(['N2',t('Time progress','时间进度'),percent(progress)]);
    } else {
      result.formula = `=${actualAddress}-${targetAddress}`;
      result.explanation = t(`Actual − target = ${item.gap}. Negative gaps are shown in parentheses.`,`实际 − 目标 = ${item.gap}；负差距用括号显示。`);
    }
  }
  result.inputCount = result.inputs.length;
  return result;
}

function mountReport(root) {
  const lang = document.documentElement.lang === 'zh-CN' ? 'zh' : 'en';
  const t = (en,zh) => choose(lang,en,zh);
  const escape = value => String(value).replace(/[&<>"']/g,char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const dateInput = root.querySelector('#lead-report-date');
  let model = createReport(dateInput.value,lang);
  let selected = {row:0,product:0,kind:'rate'};
  const kinds = ['actual','target','rate','gap'];
  const kindLabels = [t('Actual','实际'),t('Target','目标'),t('Attainment','达成率'),t('Gap','差距')];
  const keyOf = selection => `${selection.row}:${selection.product}:${selection.kind}`;
  const cellButton = (rowIndex,p,kind,value,css='') => {
    const key = keyOf({row:rowIndex,product:p,kind});
    const row = rowIndex === 'total' ? model.total : model.rows[rowIndex];
    const label = `${row.region} ${kind === 'opportunity' ? t('Sales opportunities','销售机会') : `${model.products[p]} ${kindLabels[kinds.indexOf(kind)]}`} ${value} · ${t('View formula','查看公式')}`;
    return `<td class="${css}"><button type="button" data-lead-key="${key}" aria-pressed="false" aria-label="${escape(label)}">${escape(value)}</button></td>`;
  };
  const renderRow = (row,rowIndex) => {
    let result = `<tr><th scope="row">${escape(row.region)}</th>${cellButton(rowIndex,0,'opportunity',row.opportunities)}`;
    row.products.forEach((item,p) => {
      result += cellButton(rowIndex,p,'actual',item.actual);
      result += cellButton(rowIndex,p,'target',item.target);
      result += cellButton(rowIndex,p,'rate',percent(item.rate),item.rate >= model.progress ? 'lead-on-track' : 'lead-behind');
      result += cellButton(rowIndex,p,'gap',item.gap < 0 ? `(${Math.abs(item.gap)})` : item.gap,item.gap < 0 ? 'lead-negative' : '');
    });
    return result+'</tr>';
  };
  const selectCell = selection => {
    selected = selection;
    const description = describeCell(model,selection);
    root.querySelectorAll('[data-lead-key]').forEach(button => button.setAttribute('aria-pressed',String(button.dataset.leadKey === keyOf(selection))));
    root.querySelector('[data-lead-cell]').textContent = description.address;
    root.querySelector('[data-lead-address]').textContent = description.address;
    root.querySelector('[data-lead-value]').textContent = description.value;
    root.querySelector('[data-lead-context]').textContent = description.context;
    root.querySelector('[data-lead-formula]').textContent = description.formula;
    root.querySelector('[data-lead-formula-short]').textContent = description.formula;
    root.querySelector('[data-lead-explanation]').textContent = description.explanation;
    const rule = root.querySelector('[data-lead-rule]');
    rule.hidden = !description.rule;
    rule.textContent = description.rule;
    const headers = description.headers.map(header => `<th scope="col">${escape(header)}</th>`).join('');
    const displayedInputs = description.inputs.slice(0,5);
    const inputs = displayedInputs.map(row => `<tr>${row.map(value => `<td>${escape(value)}</td>`).join('')}</tr>`).join('');
    const count = t(`${description.inputCount} matching input rows; showing ${displayedInputs.length}.`,`共 ${description.inputCount} 条引用／匹配记录，显示 ${displayedInputs.length} 条。`);
    root.querySelector('[data-lead-inputs]').innerHTML = `<p>${escape(count)}</p><div class="lead-input-scroll"><table><thead><tr>${headers}</tr></thead><tbody>${inputs}</tbody></table></div>`;
  };
  const render = () => {
    const letters = Array.from({length:22},(_,i) => `<th scope="col">${column(i)}</th>`).join('');
    root.querySelector('[data-lead-head]').innerHTML = `<tr class="lead-column-letters">${letters}</tr><tr class="lead-group-head"><th rowspan="2" scope="col">${t('Region','区域')}</th><th rowspan="2" scope="col">${t('Sales<br>opportunities','销售机会')}</th>${model.products.map(product => `<th colspan="4" scope="colgroup">${escape(product)}${t(' · month to date','意向 · 月累计')}</th>`).join('')}</tr><tr class="lead-measure-head">${model.products.map(() => kindLabels.map(label => `<th scope="col">${label}</th>`).join('')).join('')}</tr>`;
    root.querySelector('[data-lead-body]').innerHTML = model.rows.map((row,i) => renderRow(row,i)).join('');
    root.querySelector('[data-lead-foot]').innerHTML = renderRow(model.total,'total');
    root.querySelector('[data-lead-progress-value]').textContent = percent(model.progress);
    selectCell(selected);
  };
  root.addEventListener('click',event => {
    const button = event.target.closest('[data-lead-key]');
    if (button) {
      const [row,p,kind] = button.dataset.leadKey.split(':');
      selectCell({row:row === 'total' ? 'total' : Number(row),product:Number(p),kind});
    }
    if (event.target.closest('[data-lead-progress]')) selectCell({row:0,product:0,kind:'progress'});
  });
  root.addEventListener('keydown',event => {
    const button = event.target.closest('[data-lead-key]');
    if (!button || !['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)) return;
    const allRows = [...root.querySelector('.lead-report-table').querySelectorAll('tbody tr, tfoot tr')];
    const row = button.closest('tr');
    const rowIndex = allRows.indexOf(row);
    const rowButtons = [...row.querySelectorAll('[data-lead-key]')];
    const colIndex = rowButtons.indexOf(button);
    const nextRow = allRows[rowIndex + (event.key === 'ArrowDown' ? 1 : event.key === 'ArrowUp' ? -1 : 0)];
    const nextCol = colIndex + (event.key === 'ArrowRight' ? 1 : event.key === 'ArrowLeft' ? -1 : 0);
    const next = nextRow?.querySelectorAll('[data-lead-key]')[nextCol];
    if (next) {event.preventDefault();next.focus();next.click();}
  });
  dateInput.addEventListener('change',() => {
    try {model = createReport(dateInput.value,lang);render();}
    catch {dateInput.value=model.cutoff;}
  });
  render();
}
if (typeof document !== 'undefined') document.querySelectorAll('.lead-report-demo').forEach(mountReport);
